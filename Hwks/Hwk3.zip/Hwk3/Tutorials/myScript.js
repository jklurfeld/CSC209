function myFunction() {
  document.getElementById("demo").innerHTML = "Paragraph changed.";
}

function func(){
    document.getElementsByTagName("body")[0].innerHTML += "<h1>hello world</h1>";
}