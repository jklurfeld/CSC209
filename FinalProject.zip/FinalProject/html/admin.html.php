<?php
session_start();
?>

<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel=stylesheet href="../Resources/bootstrap/css/bootstrap.min.css">
        <script src="../Resources/jquery/jquery-3.7.1.min.js"></script>
        <script src="../Resources/bootstrap/js/bootstrap.bundle.min.js"></script>
        <?php include "../php/functions.php"; ?>
        <script src="../js/myLib.js"></script>
    </head>
    <body>
        <?php include "navBar.html.php"; ?>

        <h4>Manage Users</h3>
        <button onclick="refresh()">Refresh</button>
        <div id="tableDiv" class="container">
        <?php 
        $users = fileToArray("../json/users.json");
        createTable($users);
        ?>
        </div>
        <br>
        <h4>Create a new past performance post</h4>
        <form action="../php/scripts/createPastPerformance.php" method="post">
        Video Link: <input type="text" name="videoLink"><br>
        Date: <input type="date" name="date"><br>
        Title: <input type="text" name="title"><br>
        Description: <textarea type="text" name="description" rows="5" cols ="40"></textarea><br>
        <input type="submit">
        </form>

        <h4>Past Performances</h4>
        <div id="ppDiv">
        <?php
        $path = "../json/past/*.json";
        $pastPerformances = glob($path);
        createTablePerformances($pastPerformances);
        ?>
        </div>
    </body>

</html>